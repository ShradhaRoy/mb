package com.cg.billing.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class BilligExceptionAspect {

}
